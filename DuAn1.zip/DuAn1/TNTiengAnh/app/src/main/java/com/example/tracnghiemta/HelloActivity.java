package com.example.tracnghiemta;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class HelloActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello);
//        getSupportActionBar().hide();
        //Full Screen
        View decorView = getWindow().getDecorView();
// Hide the status bar.
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
//        //Dùng cài đặt sau 5 giây màn hình tự chuyển
        Thread bamgio = new Thread() {
            public void run() {
                try {
                    sleep(5000);
                } catch (Exception e) {

                } finally {
                    Intent activitymoi = new Intent(HelloActivity.this, MainActivity.class);
                    startActivity(activitymoi);
                }
            }
        };
        bamgio.start();
    }

    //
//    //sau khi chuyển sang màn hình chính, kết thúc màn hình chào
    protected void onPause() {
        super.onPause();
        finish();
    }
}