package com.example.tracnghiemta.grammar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.tracnghiemta.R;

public class PresentSimpleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_present_simple);
    }
}
