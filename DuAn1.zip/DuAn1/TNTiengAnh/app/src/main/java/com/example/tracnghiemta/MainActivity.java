package com.example.tracnghiemta;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.tracnghiemta.grammar.GrammarFragment;
import com.example.tracnghiemta.infomation.InfomationFragment;
import com.example.tracnghiemta.question.DBHelper;
import com.example.tracnghiemta.score.ScoreFragment;
import com.example.tracnghiemta.subjects.HomeFragment;
import com.example.tracnghiemta.translate.GGTranslateActivity;
import com.example.tracnghiemta.translate.MicrosoftTranslateActivity;
import com.example.tracnghiemta.translate.TranslateFragment;

import java.io.IOException;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);
        Toolbar toolbar =findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


    DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        HomeFragment homeFragment = new HomeFragment();
        FragmentManager manager = getSupportFragmentManager();
        manager.beginTransaction().replace(R.id.content_main, homeFragment, homeFragment.getTag()).commit();

        DBHelper db = new DBHelper(this);

        try {
            db.createDataBase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Kiem tra va cap quyen internet
        int permission_internet = ContextCompat.checkSelfPermission(this,
                Manifest.permission.INTERNET);


        if (permission_internet != PackageManager.PERMISSION_GRANTED ){
            makeRequest();
        }

    }

    protected void makeRequest() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET,
                Manifest.permission.SEND_SMS, Manifest.permission.CAMERA}, 1);
    }
//



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.home) {
            // Handle the camera action
            HomeFragment homeFragment = new HomeFragment();
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.content_main, homeFragment, homeFragment.getTag()).commit();
        }
//        else if (id == R.id.montoan) {
//            EnglishFragment toanFragment = new EnglishFragment();
//            FragmentManager manager = getSupportFragmentManager();
//            manager.beginTransaction().replace(R.id.content_main, toanFragment, toanFragment.getTag()).commit();
//        }
        else if (id == R.id.translate) {
            TranslateFragment translateFragment = new TranslateFragment();
             FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.content_main, translateFragment, translateFragment.getTag()).commit();
        }
        else if (id == R.id.info) {
            InfomationFragment infomationFragment = new InfomationFragment();
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.content_main, infomationFragment, infomationFragment.getTag()).commit();
        }
        else if (id == R.id.grammar) {
            GrammarFragment grammarFragment = new GrammarFragment();
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.content_main, grammarFragment, grammarFragment.getTag()).commit();
        }
        else if (id == R.id.score) {
            ScoreFragment scoreFragment = new ScoreFragment();
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.content_main, scoreFragment, scoreFragment.getTag()).commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void google(View view) {
        Intent intent=new Intent(this, GGTranslateActivity.class);
        startActivity(intent);
    }

    public void microsoft(View view) {
        Intent intent=new Intent(this, MicrosoftTranslateActivity.class);
        startActivity(intent);

    }
}
