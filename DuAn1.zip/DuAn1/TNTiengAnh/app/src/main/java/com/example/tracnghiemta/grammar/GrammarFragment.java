package com.example.tracnghiemta.grammar;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.tracnghiemta.R;
import com.example.tracnghiemta.translate.GGTranslateActivity;
import com.example.tracnghiemta.translate.MicrosoftTranslateActivity;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link GrammarFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link GrammarFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GrammarFragment extends ListFragment {
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String[] values = new String[]{"HIỆN TẠI ĐƠN (Present Simple)", "HIỆN TẠI TIẾP DIỄN (Present Continuous",
                "Hiện tại hoàn thành (Present Perfect)", "Quá khứ đơn (Past simple),"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1, values);
        setListAdapter(adapter);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        // TODO implement some logic
        if(position==0) {
            Intent intent = new Intent(getContext(), PresentSimpleActivity.class);
            startActivity(intent);
        }
        else if (position==1){
            Intent intent = new Intent(getContext(), PresentSimpleActivity.class);
            startActivity(intent);

        }
        else {
            Intent intent = new Intent(getContext(), PresentSimpleActivity.class);
            startActivity(intent);

        }
    }
}


