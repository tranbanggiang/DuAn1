package com.example.tracnghiemta.translate;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

import com.example.tracnghiemta.R;

public class GGTranslateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ggtranslate);
        WebView myWebView=findViewById(R.id.ggdich);
        myWebView.loadUrl("http://translate.google.com/");
    }


}
