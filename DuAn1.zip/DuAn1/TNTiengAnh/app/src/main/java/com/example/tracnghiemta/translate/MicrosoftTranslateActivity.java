package com.example.tracnghiemta.translate;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

import com.example.tracnghiemta.R;

public class MicrosoftTranslateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_microsoft_translate);
        WebView myWebView=findViewById(R.id.mcrtran);
        myWebView.loadUrl("http://translate.google.com/");
    }
}
